# coding: utf-8

from .user import User


class MP(User):
    """
    公众号对象
    """
    pass
