# coding: utf-8

from .utils import shell_entry

if __name__ == '__main__':
    shell_entry()
